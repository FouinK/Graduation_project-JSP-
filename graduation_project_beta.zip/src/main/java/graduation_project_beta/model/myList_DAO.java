package graduation_project_beta.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class myList_DAO {
	public ArrayList<myList_DTO> arraylist_my;
	
	private myList_DAO() {}
	private static myList_DAO instance = new myList_DAO();
	public static myList_DAO getinstance() {return instance;}
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public Connection getConnection() {
		
		String dbURL = "jdbc:mysql://localhost:3306/GraduationDB?serverTimezone=UTC&useSSL=false";
		String dbID = "root";
		String dbPassword = "root";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL,dbID,dbPassword);
		} catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	
	public void getMylist() {
		arraylist_my = new ArrayList<myList_DTO>();
		conn = getConnection();
		
		try {
			String sql = "select * from my_schedule";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int no_ = rs.getInt(1);
				int first_period = rs.getInt(2);
				int last_period = rs.getInt(3);
				int place_count = rs.getInt(4);
				String place_list = rs.getString(5);
				String travel_name = rs.getString(6);
				
				myList_DTO s = new myList_DTO(no_,first_period,last_period,place_count,place_list,travel_name);
				arraylist_my.add(s);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void setMylist(int first_period, int last_period, int place_count, String place_list, String travel_name) {
		conn = getConnection();
		
		try {
			String sql = "select * from my_schedule";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			//select문으로 no값만 가져옴 > ++한 후 넣기
			int no_ = 0;
			while(rs.next()) {
				no_ = rs.getInt(1);
			}
			
			sql = "insert into my_schedule values(?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,++no_);
			pstmt.setInt(2,first_period);
			pstmt.setInt(3,last_period);
			pstmt.setInt(4, place_count);
			pstmt.setString(5, place_list);
			pstmt.setString(6, travel_name);
			
			pstmt.executeUpdate();
			
			conn.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
}