package graduation_project_beta.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import graduation_project_beta.model.myList_DAO;
import graduation_project_beta.model.myList_DTO;
import graduation_project_beta.model.user_schedule_DAO;

@WebServlet("/myList_delete.do")
public class myList_deleteCon extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		reqPro(request ,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		reqPro(request ,response);
	}
	protected void reqPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		myList_DAO instance = myList_DAO.getinstance();
		instance.getMylist();
		int no = Integer.parseInt(request.getParameter("no__"));
		user_schedule_DAO instance1 = user_schedule_DAO.getinstance();
		instance1.getUser_schedule();
		
		
		for(int i=0;i<instance.arraylist_my.size();i++) {
			if(no == instance.arraylist_my.get(i).getNo_()) {
				if(instance.arraylist_my.get(i).getCheck_() == 10) {
					for(int j=0;j<instance1.arraylist_user_schedule.size();j++) {
						if(instance.arraylist_my.get(i).getFirst_period() == instance1.arraylist_user_schedule.get(j).getFirst_period() && instance.arraylist_my.get(i).getLast_period() == instance1.arraylist_user_schedule.get(j).getLast_period() && instance.arraylist_my.get(i).getPlace_count() == instance1.arraylist_user_schedule.get(j).getPlace_count() && instance.arraylist_my.get(i).getPlace_list().equals(instance1.arraylist_user_schedule.get(j).getPlace_list()) && instance.arraylist_my.get(i).getTravel_name().equals(instance1.arraylist_user_schedule.get(j).getTravel_name())) {
							instance1.delete_user_schedule(instance1.arraylist_user_schedule.get(j).getTravel_name());
						}
					}
				}
			}
		}
		
		instance.deleteMylist(no);
		request.setAttribute("arraylist_my", instance.arraylist_my);
		
		RequestDispatcher dis = request.getRequestDispatcher("my_schedule.jsp");
		dis.forward(request, response);
		/*RequestDispatcher dis1 = request.getRequestDispatcher("user_schedule.jsp");
		dis1.forward(request, response);*/
	}
}