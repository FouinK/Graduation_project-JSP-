package graduation_project_beta.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import graduation_project_beta.model.myList_DAO;
import graduation_project_beta.model.user_schedule_DAO;

@WebServlet("/make_my_schedule.do")
public class make_my_scheduleCon extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		reqPro(request ,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		reqPro(request ,response);
	}
	protected void reqPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		myList_DAO instance = myList_DAO.getinstance();
		int first_period = Integer.parseInt(request.getParameter("first_period"));
		int last_period = Integer.parseInt(request.getParameter("last_period"));
		int place_count = Integer.parseInt(request.getParameter("place_count"));
		String place_list = request.getParameter("place_list");
		String travel_name = request.getParameter("travel_name");
		instance.setMylist(first_period, last_period, place_count, place_list, travel_name);
		instance.getMylist();
		
		
		request.setAttribute("arraylist_my", instance.arraylist_my);
		RequestDispatcher dis = request.getRequestDispatcher("my_schedule.jsp");
		dis.forward(request, response);
	}
}
