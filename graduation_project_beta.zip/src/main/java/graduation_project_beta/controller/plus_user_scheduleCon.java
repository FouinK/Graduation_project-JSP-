package graduation_project_beta.controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import graduation_project_beta.model.myList_DAO;
import graduation_project_beta.model.user_schedule_DAO;

@WebServlet("/plus_user_schedule.do")
public class plus_user_scheduleCon extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		reqPro(request ,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		reqPro(request ,response);
	}
	protected void reqPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		myList_DAO instance = myList_DAO.getinstance();
		
		
		user_schedule_DAO instance1 = user_schedule_DAO.getinstance();
		String region = request.getParameter("region");
		int first_period = Integer.parseInt(request.getParameter("first_period"));
		int last_period = Integer.parseInt(request.getParameter("last_period"));
		int place_count = Integer.parseInt(request.getParameter("place_count"));
		String place_list = request.getParameter("place_list");
		String travel_name = request.getParameter("travel_name");
		String travel_content_my="~~";
		
		instance1.getUser_schedule();
		int no = Integer.parseInt(request.getParameter("no_"));
		instance.getMylist();
		for(int i=0;i<instance.arraylist_my.size();i++) {
			if(no == instance.arraylist_my.get(i).getNo_()) {
				if(instance.arraylist_my.get(i).getCheck_()!=10) {
					instance1.setUser_schedule(region,first_period, last_period, place_count, place_list, travel_name, travel_content_my);
				}
			}
		}
		
		instance.editMylist(no);
		
		request.setAttribute("arraylist_user_schedule_", instance1.arraylist_user_schedule);
		RequestDispatcher dis = request.getRequestDispatcher("user_schedule.jsp");
		dis.forward(request, response);
		/*int check = instance1.getMylist_for_userschedule(no_,first_period,last_period,place_count,place_list,travel_name);
		instance1.getUser_schedule();
		if(check!=2) {
			instance1.setUser_schedule(first_period, last_period, place_count, place_list, travel_name, travel_content_my);
		}
		request.setAttribute("arraylist_user_schedule_", instance1.arraylist_user_schedule);
		RequestDispatcher dis = request.getRequestDispatcher("user_schedule.jsp");
		dis.forward(request, response);
		*/
	}
}
