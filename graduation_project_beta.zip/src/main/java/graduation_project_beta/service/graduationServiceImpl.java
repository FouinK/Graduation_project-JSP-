package graduation_project_beta.service;

import graduation_project_beta.model.DAO;
import graduation_project_beta.model.myList_DAO;
import graduation_project_beta.model.user_schedule_DAO;

public class graduationServiceImpl implements graduationService{
	private DAO dao = new DAO();
	private myList_DAO mylist_dao = new myList_DAO();
	private user_schedule_DAO user_schedule_dao = new user_schedule_DAO();

	

}
