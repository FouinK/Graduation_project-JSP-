package graduation_project_beta.service;

public interface graduationService {

}
