package graduation_project_beta.service;

public interface graduationService {
	
	//key.equals에 있는 거 내일정 , 로그인 버튼 같은 느낌 
}
